program kopia_backup_cron;

uses
  Forms,
  Unit1 in 'Unit1.pas' {Form1};

{$R *.res}
{$R Res.res}
begin
  Application.Initialize;
  Application.ShowMainForm := False; // ������һ��
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.

